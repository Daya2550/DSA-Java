package javadsa.MainHelper;

import java.util.Scanner;

import javadsa.Indexing.Sorting;
import javadsa.Indexing.StackAndQueue;
import javadsa.Indexing.serching;

public class MainHelper {
    public void ToStart(){
        Scanner sc = new Scanner(System.in);
        int choice = 0;
        MainHeding ();
        
        // System.out.println("Welcome to Data Structures and Algorithms in Java");
        // System.out.println("--------------------------------------------------");
      do{
        System.out.println("Choose an option:");
        System.out.println("1. Serching Algorithms:");
         System.out.println("2. Sorting Algorithms:");
         System.out.println("3. Stack and Queue Implementation");
         System.out.println("4. Linked List Implementation");
        System.out.println("5. Information about Data Structures:");
        System.out.print("6. Exit :");
        
                             ;
            try {   
            choice = sc.nextInt();  
        }
        catch (Exception e) {
            System.out.println("Some thing went Wrong !");
            MainHelper mainHelper = new MainHelper();
                mainHelper.ErrorMessage();
                  ToStart();
        }
       
         
       
        switch (choice) {
            case 1:
             
               try {
                serching ser= new serching();
               ser.search();
               } catch (Exception e) {
                        System.out.println("Some thing went Wrong !");
                        MainHelper mainHelper = new MainHelper();
                        mainHelper.ErrorMessage();
                        new MainHelper().ToStart();
               }
                break;
        
            case 2:
                Sorting sort = new Sorting();
                sort.Sort();
                try {
                    
                } catch (Exception e) {
                     System.out.println("Some thing went Wrong !");
                    MainHelper mainHelper = new MainHelper();
                        mainHelper.ErrorMessage();
                        new MainHelper().ToStart();
                }
                break;    
            
            case 3:
                
                try {
                 StackAndQueue sq = new StackAndQueue();
                sq.choice();
             } catch (Exception e) {
                    System.out.println("Some thing went Wrong !");
                    MainHelper mainHelper = new MainHelper();
                        mainHelper.ErrorMessage();
                        new MainHelper().ToStart();
                }
                break; 
            
            case 4:
                
                try {
                    javadsa.Indexing.LinkedList ll = new javadsa.Indexing.LinkedList();
                ll.LL();
                } catch (Exception e) {
                     System.out.println("Some thing went Wrong !");
                    MainHelper mainHelper = new MainHelper();
                        mainHelper.ErrorMessage();
                        new MainHelper().ToStart();
                }
                break;
                
            case 5:
              
                try {
                  information info1 = new information();
                       info1.TogetDifination();
                } catch (Exception e) {
                     System.out.println("Some thing went Wrong !");
                    MainHelper mainHelper = new MainHelper();
                        mainHelper.ErrorMessage();
                        new MainHelper().ToStart();
                }
                break;

            case 6:
                  System.out.println("Exiting the program.");
                break;    
                    
            default:
                System.out.println("Invalid choice, please try again.");
                break;
      }
     }
        while(choice!=4);    


    
    }


    public void MainHeding (){
String MainHeding =   """


                       ██╗    ██╗  ███████╗  ██╗        ██████╗   ██████╗   ███╗   ███╗  ███████╗
                       ██║    ██║  ██╔════╝  ██║       ██╔════╝  ██╔═══██╗  ████╗ ████║  ██╔════╝
                       ██║ █╗ ██║  █████╗    ██║       ██║       ██║   ██║  ██╔████╔██║  █████╗  
                       ██║███╗██║  ██╔══╝    ██║       ██║       ██║   ██║  ██║╚██╔╝██║  ██╔══╝  
                       ╚███╔███╔╝  ███████╗  ███████╗  ╚██████╗  ╚██████╔╝  ██║ ╚═╝ ██║  ███████╗
                        ╚══╝╚══╝   ╚══════╝  ╚══════╝   ╚═════╝   ╚═════╝   ╚═╝     ╚═╝  ╚══════╝
  
                                                    W E L C O M E

        """;
           

        System.out.println(MainHeding);
        String subHeading = """
                                         ████████╗   ██████╗     ██████╗   ███████╗   █████╗ 
                                         ╚══██╔══╝  ██╔═══██╗    ██╔══██╗  ██╔════╝  ██╔══██╗
                                            ██║     ██║   ██║    ██║  ██║  ███████╗  ███████║
                                            ██║     ██║   ██║    ██║  ██║  ╚════██║  ██╔══██║
                                            ██║     ╚██████╔╝    ██████╔╝  ███████║  ██║  ██║
                                            ╚═╝      ╚═════╝     ╚═════╝   ╚══════╝  ╚═╝  ╚═╝
                                         
                                                                T O   D S A

                """;
        System.out.println(subHeading);

}


public void ErrorMessage(){
  String errorMessage = """


                                 ███████╗ ██████╗   ██████╗    ██████╗   ██████╗ 
                                 ██╔════╝ ██╔══██╗  ██╔══██╗  ██╔═══██╗  ██╔══██╗
                                 █████╗   ██████╔╝  ██████╔╝  ██║   ██║  ██████╔╝
                                 ██╔══╝   ██╔══██╗  ██╔══██╗  ██║   ██║  ██╔══██╗
                                 ███████╗ ██║  ██║  ██║  ██║  ╚██████╔╝  ██║  ██║
                                 ╚══════╝ ╚═╝  ╚═╝  ╚═╝  ╚═╝   ╚═════╝   ╚═╝  ╚═╝
                                 
                                                   E R R O R

  """;
  System.out.println(errorMessage);
}
}






class information {
    public void TogetDifination(){
        String defination ="A data structure is a technique to systematically store data so that the data can be easily and" + 
                           "effectively created, accessed, and managed. This system collects data values";
        String typesofdata ="1. Linear Data Structure: In a linear data structure, data elements are arranged in a sequential manner, " +
                             "where each element is connected to its previous and next element. Examples include arrays, linked lists, stacks, and queues." +
                             "\n2. Non-Linear Data Structure: In a non-linear data structure, data elements are not arranged in a sequential manner. " +
                             "Instead, they are organized in a hierarchical or interconnected manner. Examples include trees and graphs.";     

                  System.out.println("Defination of Data Structure: \n" + defination);
                  System.out.println();   
                  System.out.println("\nTypes of Data Structure: \n" + typesofdata); 
                  System.out.println();          
                            
    }
}

