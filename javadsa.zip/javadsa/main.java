
package javadsa;

import javadsa.MainHelper.MainHelper;

public class main {
    public static void main(String[] args){
         new MainHelper().ToStart();
    }
}
